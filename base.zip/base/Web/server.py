﻿# -*- coding: utf-8 -*-
from flask import Flask, render_template, request

import datetime
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np

app = Flask(__name__)

X = tf.placeholder(tf.float32, shape=[None, 4])
Y = tf.placeholder(tf.float32, shape=[None, 1])
W = tf.Variable(tf.random_normal([4, 1]), name="weight")
b = tf.Variable(tf.random_normal([1]), name="bias")

hypothesis = tf.matmul(X, W) + b
saver = tf.train.Saver()
model = tf.global_variables_initializer()

sess = tf.Session()
sess.run(model)

save_path = "./model/saved.cpkt"
saver.restore(sess, save_path)



@app.route("/")
def index():
    return render_template('index.html')    # 메인 페이지

@app.route("/using")
def using():
    return render_template('using.html')    # How Make? (using) 페이지

@app.route("/profile")
def profile():
    return render_template('profile.html')    # Menu1 페이지 - 프로필

@app.route("/reference")
def reference():
    return render_template('reference.html')    # Menu2 페이지 - 참고 자료

@app.route("/predict", methods=['GET', 'POST'])
def predict():
    if request.method == 'GET':
        return render_template('predict.html')  # Menu3 페이지 - predict 배추 가격 예측
    if request.method == 'POST':
        avg_temp = float(request.form['avg_temp'])
        min_temp = float(request.form['min_temp'])
        max_temp = float(request.form['max_temp'])
        rain_fall = float(request.form['rain_fall'])

        price = 0   # 배추가격 선언

        data = ((avg_temp, min_temp, max_temp, rain_fall), (0, 0, 0, 0))        # 입력된 파라미터 배열 형태로 
        arr = np.array(data, dtype=np.float32)

        x_data = arr[0:4]       # 입력 값으로 예측 값 도출
        dict = sess.run(hypothesis, feed_dict={X: x_data})

        price = dict[0]     # 배추가격 저장

        return render_template('predict.html', price=price)

@app.route("/menu4")
def menu4():
    return render_template('menu4.html')    # Menu4 페이지 - 아직 없음

@app.route("/menu5")
def menu5():
    return render_template('menu5.html')    # Menu5 페이지 - 아직 없음


if __name__ == '__main__':
   app.run(debug = True)